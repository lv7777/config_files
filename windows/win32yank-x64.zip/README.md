
A clipboard tool for Windows.

Get the clipboard.

    win32yank -o

Set the clipboard

    echo "hello brave new world!" | win32yank -i

